SET IDENTITY_INSERT [dbo].[tblAgents] ON
INSERT INTO [dbo].[tblAgents] ([AgentID], [AgentName], [AgentStatus], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (1, N'Agent 1', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
INSERT INTO [dbo].[tblAgents] ([AgentID], [AgentName], [AgentStatus], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (2, N'Agent 2', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
INSERT INTO [dbo].[tblAgents] ([AgentID], [AgentName], [AgentStatus], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (3, N'Agent 3', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', NULL)
SET IDENTITY_INSERT [dbo].[tblAgents] OFF
