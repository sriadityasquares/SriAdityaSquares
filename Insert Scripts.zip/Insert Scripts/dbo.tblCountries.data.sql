SET IDENTITY_INSERT [dbo].[tblCountries] ON
INSERT INTO [dbo].[tblCountries] ([CountryID], [CountryName], [Status], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (1, N'India', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
INSERT INTO [dbo].[tblCountries] ([CountryID], [CountryName], [Status], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (2, N'USA', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
SET IDENTITY_INSERT [dbo].[tblCountries] OFF
