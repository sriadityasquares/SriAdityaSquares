SET IDENTITY_INSERT [dbo].[tblCity] ON
INSERT INTO [dbo].[tblCity] ([CityID], [StateID], [CityName], [Status], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (1, 1, N'Visakhapatnam', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
INSERT INTO [dbo].[tblCity] ([CityID], [StateID], [CityName], [Status], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (2, 1, N'Vijayawada', N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
SET IDENTITY_INSERT [dbo].[tblCity] OFF
