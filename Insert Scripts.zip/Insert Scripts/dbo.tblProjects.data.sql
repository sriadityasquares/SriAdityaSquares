SET IDENTITY_INSERT [dbo].[tblProjects] ON
INSERT INTO [dbo].[tblProjects] ([ProjectID], [ProjectName], [ProjectLocation], [BookingStatus], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ClubHouseCharges]) VALUES (1, N'Project 1', N'Gachibowli', N'O', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00', 150000)
INSERT INTO [dbo].[tblProjects] ([ProjectID], [ProjectName], [ProjectLocation], [BookingStatus], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ClubHouseCharges]) VALUES (2, N'Project 2', N'Jubliee Hills', N'O', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00', 100000)
INSERT INTO [dbo].[tblProjects] ([ProjectID], [ProjectName], [ProjectLocation], [BookingStatus], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ClubHouseCharges]) VALUES (3, N'Project 3', N'Banjara Hills', N'O', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00', 200000)
SET IDENTITY_INSERT [dbo].[tblProjects] OFF
