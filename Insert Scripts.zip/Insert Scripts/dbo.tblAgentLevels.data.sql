SET IDENTITY_INSERT [dbo].[tblAgentLevels] ON
INSERT INTO [dbo].[tblAgentLevels] ([LevelID], [LevelName], [Percentage], [Status], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (1, N'Level 1', 5, N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
INSERT INTO [dbo].[tblAgentLevels] ([LevelID], [LevelName], [Percentage], [Status], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (2, N'Level 2', 10, N'A', N'Admin', N'2019-10-12 00:00:00', N'Admin', N'2019-10-12 00:00:00')
SET IDENTITY_INSERT [dbo].[tblAgentLevels] OFF
